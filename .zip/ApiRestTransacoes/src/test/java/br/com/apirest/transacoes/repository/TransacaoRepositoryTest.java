package br.com.apirest.transacoes.repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import br.com.apirest.transacoes.model.Transacao;

@RunWith(MockitoJUnitRunner.class)
public class TransacaoRepositoryTest {

	@InjectMocks
	private TransacaoRepository transacaoRepository;
	
	@Test
	public void buscarTransacoes_sem_transacoes() {
		
		List<Transacao> retorno = transacaoRepository.buscarTransacoes();
		
		Assert.assertNotNull(retorno);
		Assert.assertEquals(0, retorno.size());
	}
	
	@Test
	public void buscarTransacoes_com_transacoes() {
		
		Transacao transacao = new Transacao(new BigDecimal("100.00"), LocalDateTime.now());
		transacaoRepository.salvarTransacao(transacao);
		
		List<Transacao> retorno = transacaoRepository.buscarTransacoes();
		
		Assert.assertNotNull(retorno);
		Assert.assertEquals(1, retorno.size());
	}
	
	@Test
	public void buscarTransacoes_deletando_transacoes() {
		
		Transacao transacao = new Transacao(new BigDecimal("100.00"), LocalDateTime.now());
		transacaoRepository.salvarTransacao(transacao);
		
		transacaoRepository.deletarTransacoes();
		
		List<Transacao> retorno = transacaoRepository.buscarTransacoes();
		
		Assert.assertNotNull(retorno);
		Assert.assertEquals(0, retorno.size());
	}
	
	@Test
	public void buscarTransacoesUltimoMinuto_com_transacoes_maiores_1_min() {
		
		Transacao transacao = new Transacao(new BigDecimal("100.00"), LocalDateTime.now().plusMinutes(1));
		transacaoRepository.salvarTransacao(transacao);
		
		List<Transacao> retorno = transacaoRepository.buscarTransacoesUltimoMinuto();
		
		Assert.assertNotNull(retorno);
		Assert.assertEquals(0, retorno.size());
		
	}
	
	@Test
	public void buscarTransacoesUltimoMinuto_com_transacoes_menores_2_min() {
		
		Transacao transacao = new Transacao(new BigDecimal("100.00"), LocalDateTime.now().minusMinutes(2));
		transacaoRepository.salvarTransacao(transacao);
		
		List<Transacao> retorno = transacaoRepository.buscarTransacoesUltimoMinuto();
		
		Assert.assertNotNull(retorno);
		Assert.assertEquals(0, retorno.size());
		
	}
	
	@Test
	public void buscarTransacoesUltimoMinuto_com_transacoes_corrente() {
		
		Transacao transacao = new Transacao(new BigDecimal("100.00"), LocalDateTime.now());
		transacaoRepository.salvarTransacao(transacao);
		
		List<Transacao> retorno = transacaoRepository.buscarTransacoesUltimoMinuto();
		
		Assert.assertNotNull(retorno);
		Assert.assertEquals(1, retorno.size());
		
	}
	
	@Test
	public void buscarTransacoesUltimoMinuto_com_transacoes_corrente_menos_1_min() {
		
		Transacao transacao = new Transacao(new BigDecimal("100.00"), LocalDateTime.now().minusMinutes(1));
		transacaoRepository.salvarTransacao(transacao);
		
		List<Transacao> retorno = transacaoRepository.buscarTransacoesUltimoMinuto();
		
		Assert.assertNotNull(retorno);
		Assert.assertEquals(1, retorno.size());
		
	}
	
}
