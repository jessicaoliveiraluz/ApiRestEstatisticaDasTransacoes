package br.com.apirest.transacoes.integracao;

public class DeletarTransacoesTest {

}
